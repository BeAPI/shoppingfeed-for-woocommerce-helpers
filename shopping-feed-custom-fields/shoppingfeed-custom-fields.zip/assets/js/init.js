var sf_options

(function ($, undefined) {

  $('.acf').multi({
    'non_selected_header': sf_options.unselected,
    'selected_header': sf_options.selected,
    'search_placeholder': sf_options.search
  });

})(jQuery);
